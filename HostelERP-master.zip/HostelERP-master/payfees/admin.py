from django.contrib import admin
from .models import Dues
# Register your models here.

admin.site.register(Dues)