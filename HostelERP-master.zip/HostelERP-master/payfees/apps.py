from django.apps import AppConfig


class PayfeesConfig(AppConfig):
    name = 'payfees'
