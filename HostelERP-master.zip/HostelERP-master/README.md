# HostelERP

Hostel Management System

Developed on the Django web framework, it uses Service Oriented Architecture (SOA) and focuses on providing all the required services in the hostel accommodation domain.
